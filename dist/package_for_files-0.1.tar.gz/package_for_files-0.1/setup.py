"""Соберите из созданных на уроке и в рамках домашнего задания функций пакет для работы с файлами."""

from setuptools import setup, find_packages

setup(
    name='package_for_files',
    version='0.1',
    packages=find_packages(),
    description='a package for working with files',
    author='Udodov Konstantin',
    author_email='k.udodov@bk.ru',
)
